-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-04-2025 a las 02:11:44
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inventory`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `code` varchar(20) DEFAULT NULL,
  `produc` varchar(100) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `code`, `produc`, `price`, `stock`) VALUES
(1, 'P001', 'Chocolate con nuez', 3.50, 120),
(2, 'P002', 'Brownie artesanal', 2.75, 80),
(3, 'P003', 'Galleta de avena', 1.50, 200),
(4, 'P004', 'Pastel de zanahoria', 4.00, 60),
(5, 'P005', 'Cupcake de vainilla', 2.00, 90),
(6, 'P006', 'Tarta de fresa', 5.25, 40),
(7, 'P007', 'Donut glaseado', 1.80, 150),
(8, 'P008', 'Trufa de chocolate', 0.99, 300),
(9, 'P009', 'Cheesecake clásico', 4.75, 30),
(10, 'P010', 'Muffin de arándano', 2.20, 100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `fullname`, `username`, `password`, `role`) VALUES
(1, 'Juan Pérez', 'juanp', 'juan123', 'admin'),
(2, 'Laura Martínez', 'lauram', 'laura456', 'user'),
(3, 'Carlos Ramírez', 'carlitos', 'carlos789', 'user'),
(4, 'Ana Torres', 'ana_t', 'ana101', 'admin'),
(5, 'Pedro López', 'pedrol', 'pedro202', 'user'),
(6, 'María García', 'mariag', 'maria303', 'user'),
(7, 'José Hernández', 'joseh', 'jose404', 'admin'),
(8, 'Lucía Gómez', 'luciag', 'lucia505', 'user'),
(9, 'Andrés Rojas', 'andresr', 'andres606', 'user'),
(10, 'Sofía Díaz', 'sofiad', 'sofia707', 'admin');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
